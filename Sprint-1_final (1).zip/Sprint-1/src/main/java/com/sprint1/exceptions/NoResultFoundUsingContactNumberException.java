package com.sprint1.exceptions;

public class NoResultFoundUsingContactNumberException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	

}
